# use (chmod u+x DylanOS-install.sh) to make able run 

# use (sed -i -e 's/\r$//' DylanOS-install.sh) to debug

# use (./DylanOS-install.sh) to run installer
